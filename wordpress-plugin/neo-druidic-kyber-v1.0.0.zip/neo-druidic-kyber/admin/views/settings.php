<?php
/**
 * Admin Settings Page
 *
 * @package Neo_Druidic_Kyber
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>

<div class="wrap ndk-admin-wrap">
    <h1>
        <?php _e( 'Neo-Druidic Kyber Encryption Settings', 'neo-druidic-kyber' ); ?>
        <span class="ndk-badge">ML-KEM-768</span>
    </h1>

    <p class="description">
        <?php _e( 'Configure quantum-safe encryption for your WordPress site using the NIST-standardized ML-KEM-768 (Kyber) post-quantum cryptographic algorithm.', 'neo-druidic-kyber' ); ?>
    </p>

    <div class="ndk-admin-content">
        <div class="ndk-main-column">
            <form method="post" action="">
                <?php wp_nonce_field( 'ndk-save-settings' ); ?>

                <div class="ndk-card">
                    <h2><?php _e( 'API Connection', 'neo-druidic-kyber' ); ?></h2>

                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">
                                <label for="ndk_api_url"><?php _e( 'API URL', 'neo-druidic-kyber' ); ?></label>
                            </th>
                            <td>
                                <input
                                    type="url"
                                    id="ndk_api_url"
                                    name="ndk_api_url"
                                    value="<?php echo esc_attr( get_option( 'ndk_api_url', 'https://awen01.cc' ) ); ?>"
                                    class="regular-text"
                                    required
                                >
                                <p class="description">
                                    <?php _e( 'The base URL of your Neo-Druidic Kyber API endpoint.', 'neo-druidic-kyber' ); ?>
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">
                                <label for="ndk_api_key"><?php _e( 'API Key', 'neo-druidic-kyber' ); ?></label>
                            </th>
                            <td>
                                <input
                                    type="password"
                                    id="ndk_api_key"
                                    name="ndk_api_key"
                                    value="<?php echo esc_attr( get_option( 'ndk_api_key', '' ) ); ?>"
                                    class="regular-text"
                                    autocomplete="off"
                                >
                                <p class="description">
                                    <?php _e( 'Optional API key for authentication (if required by your API endpoint).', 'neo-druidic-kyber' ); ?>
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><?php _e( 'Connection Status', 'neo-druidic-kyber' ); ?></th>
                            <td>
                                <button type="button" id="ndk-test-connection" class="button button-secondary">
                                    <?php _e( 'Test Connection', 'neo-druidic-kyber' ); ?>
                                </button>
                                <span id="ndk-connection-status"></span>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="ndk-card">
                    <h2><?php _e( 'Encryption Features', 'neo-druidic-kyber' ); ?></h2>

                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><?php _e( 'Content Types', 'neo-druidic-kyber' ); ?></th>
                            <td>
                                <fieldset>
                                    <label>
                                        <input
                                            type="checkbox"
                                            name="ndk_encrypt_posts"
                                            value="1"
                                            <?php checked( get_option( 'ndk_encrypt_posts', false ) ); ?>
                                        >
                                        <?php _e( 'Enable encryption for Posts', 'neo-druidic-kyber' ); ?>
                                    </label>
                                    <br>
                                    <label>
                                        <input
                                            type="checkbox"
                                            name="ndk_encrypt_pages"
                                            value="1"
                                            <?php checked( get_option( 'ndk_encrypt_pages', false ) ); ?>
                                        >
                                        <?php _e( 'Enable encryption for Pages', 'neo-druidic-kyber' ); ?>
                                    </label>
                                    <br>
                                    <label>
                                        <input
                                            type="checkbox"
                                            name="ndk_encrypt_comments"
                                            value="1"
                                            <?php checked( get_option( 'ndk_encrypt_comments', false ) ); ?>
                                        >
                                        <?php _e( 'Enable encryption for Comments', 'neo-druidic-kyber' ); ?>
                                    </label>
                                </fieldset>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><?php _e( 'Key Management', 'neo-druidic-kyber' ); ?></th>
                            <td>
                                <label>
                                    <input
                                        type="checkbox"
                                        name="ndk_auto_generate_keys"
                                        value="1"
                                        <?php checked( get_option( 'ndk_auto_generate_keys', true ) ); ?>
                                    >
                                    <?php _e( 'Auto-generate encryption keys for users', 'neo-druidic-kyber' ); ?>
                                </label>
                                <p class="description">
                                    <?php _e( 'Automatically generate Kyber keypairs for users when needed. Keys are encrypted with user credentials.', 'neo-druidic-kyber' ); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <p class="submit">
                    <button type="submit" name="ndk_save_settings" class="button button-primary button-large">
                        <?php _e( 'Save Settings', 'neo-druidic-kyber' ); ?>
                    </button>
                </p>
            </form>
        </div>

        <div class="ndk-sidebar-column">
            <div class="ndk-info-card">
                <h3><?php _e( 'About ML-KEM-768', 'neo-druidic-kyber' ); ?></h3>
                <p>
                    <?php _e( 'ML-KEM-768 is the NIST-standardized post-quantum key encapsulation mechanism based on the Kyber algorithm.', 'neo-druidic-kyber' ); ?>
                </p>
                <ul>
                    <li><strong><?php _e( 'Security Level:', 'neo-druidic-kyber' ); ?></strong> NIST Level 3 (AES-192 equivalent)</li>
                    <li><strong><?php _e( 'Quantum-Safe:', 'neo-druidic-kyber' ); ?></strong> <?php _e( 'Resistant to quantum computer attacks', 'neo-druidic-kyber' ); ?></li>
                    <li><strong><?php _e( 'Standardized:', 'neo-druidic-kyber' ); ?></strong> NIST PQC 2024</li>
                </ul>
            </div>

            <div class="ndk-info-card">
                <h3><?php _e( 'Quick Start', 'neo-druidic-kyber' ); ?></h3>
                <ol>
                    <li><?php _e( 'Configure API connection above', 'neo-druidic-kyber' ); ?></li>
                    <li><?php _e( 'Test the connection', 'neo-druidic-kyber' ); ?></li>
                    <li><?php _e( 'Enable encryption for desired content types', 'neo-druidic-kyber' ); ?></li>
                    <li><?php _e( 'Edit a post/page and enable encryption in the sidebar', 'neo-druidic-kyber' ); ?></li>
                </ol>
            </div>

            <div class="ndk-info-card">
                <h3><?php _e( 'Support', 'neo-druidic-kyber' ); ?></h3>
                <p>
                    <?php printf(
                        __( 'Visit <a href="%s" target="_blank">Neo-Druidic Society</a> for documentation and support.', 'neo-druidic-kyber' ),
                        'https://awen01.cc'
                    ); ?>
                </p>
            </div>
        </div>
    </div>
</div>
