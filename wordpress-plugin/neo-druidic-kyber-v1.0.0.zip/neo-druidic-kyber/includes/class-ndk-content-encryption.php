<?php
/**
 * Content Encryption - Hooks into WordPress content
 *
 * @package Neo_Druidic_Kyber
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class NDK_Content_Encryption {

    /**
     * Constructor
     */
    public function __construct() {
        // Post/Page encryption hooks
        if ( get_option( 'ndk_encrypt_posts', false ) ) {
            add_filter( 'content_save_pre', array( $this, 'encrypt_post_content' ), 10, 1 );
            add_filter( 'the_content', array( $this, 'decrypt_post_content' ), 999, 1 );
        }

        // Comment encryption hooks
        if ( get_option( 'ndk_encrypt_comments', false ) ) {
            add_filter( 'preprocess_comment', array( $this, 'encrypt_comment_content' ), 10, 1 );
            add_filter( 'comment_text', array( $this, 'decrypt_comment_content' ), 999, 2 );
        }

        // Meta box for manual encryption
        add_action( 'add_meta_boxes', array( $this, 'add_encryption_meta_box' ) );
        add_action( 'save_post', array( $this, 'save_encryption_meta' ) );

        // Shortcode for encrypted content
        add_shortcode( 'ndk_encrypted', array( $this, 'encrypted_shortcode' ) );
    }

    /**
     * Encrypt post content before saving
     */
    public function encrypt_post_content( $content ) {
        // Only encrypt if user is logged in and has keys
        if ( ! is_user_logged_in() ) {
            return $content;
        }

        $post_id = isset( $_POST['post_ID'] ) ? intval( $_POST['post_ID'] ) : 0;

        // Check if post should be encrypted
        $should_encrypt = get_post_meta( $post_id, '_ndk_encrypt_content', true );

        if ( ! $should_encrypt ) {
            return $content;
        }

        // Encrypt for the post author
        $author_id = get_post_field( 'post_author', $post_id );
        if ( ! $author_id ) {
            $author_id = get_current_user_id();
        }

        $encrypted = NDK_Encryption::encrypt_content( $content, $author_id );

        if ( ! $encrypted ) {
            return $content; // Fallback to original if encryption fails
        }

        // Store encrypted data as post meta
        update_post_meta( $post_id, '_ndk_encrypted_data', $encrypted );
        update_post_meta( $post_id, '_ndk_is_encrypted', true );

        // Return marker content
        return '[NDK_ENCRYPTED_CONTENT]';
    }

    /**
     * Decrypt post content when displaying
     */
    public function decrypt_post_content( $content ) {
        global $post;

        if ( ! $post || ! is_user_logged_in() ) {
            return $content;
        }

        $is_encrypted = get_post_meta( $post->ID, '_ndk_is_encrypted', true );

        if ( ! $is_encrypted || $content !== '[NDK_ENCRYPTED_CONTENT]' ) {
            return $content;
        }

        $encrypted_data = get_post_meta( $post->ID, '_ndk_encrypted_data', true );

        if ( ! $encrypted_data ) {
            return '<p class="ndk-error">' . __( '[Encrypted content not available]', 'neo-druidic-kyber' ) . '</p>';
        }

        $user_id = get_current_user_id();
        $decrypted = NDK_Encryption::decrypt_content( $encrypted_data, $user_id );

        if ( ! $decrypted ) {
            return '<p class="ndk-error">' . __( '[Unable to decrypt content - you may not have permission]', 'neo-druidic-kyber' ) . '</p>';
        }

        return '<div class="ndk-decrypted-content">' . $decrypted . '</div>';
    }

    /**
     * Encrypt comment content
     */
    public function encrypt_comment_content( $commentdata ) {
        if ( ! is_user_logged_in() || empty( $commentdata['comment_content'] ) ) {
            return $commentdata;
        }

        $user_id = get_current_user_id();
        $encrypted = NDK_Encryption::encrypt_content( $commentdata['comment_content'], $user_id );

        if ( $encrypted ) {
            // Store original as comment meta (will be added after insert)
            $commentdata['comment_content'] = '[NDK_ENCRYPTED_COMMENT]';
            $commentdata['_ndk_encrypted_data'] = $encrypted;
            $commentdata['_ndk_is_encrypted'] = true;
        }

        return $commentdata;
    }

    /**
     * Decrypt comment content
     */
    public function decrypt_comment_content( $comment_text, $comment ) {
        if ( ! is_user_logged_in() || $comment_text !== '[NDK_ENCRYPTED_COMMENT]' ) {
            return $comment_text;
        }

        $encrypted_data = get_comment_meta( $comment->comment_ID, '_ndk_encrypted_data', true );

        if ( ! $encrypted_data ) {
            return __( '[Encrypted comment]', 'neo-druidic-kyber' );
        }

        $user_id = get_current_user_id();
        $decrypted = NDK_Encryption::decrypt_content( $encrypted_data, $user_id );

        return $decrypted ? $decrypted : __( '[Unable to decrypt comment]', 'neo-druidic-kyber' );
    }

    /**
     * Add encryption meta box
     */
    public function add_encryption_meta_box() {
        $post_types = array( 'post', 'page' );

        foreach ( $post_types as $post_type ) {
            add_meta_box(
                'ndk_encryption_meta_box',
                __( 'Quantum Encryption', 'neo-druidic-kyber' ),
                array( $this, 'render_encryption_meta_box' ),
                $post_type,
                'side',
                'high'
            );
        }
    }

    /**
     * Render encryption meta box
     */
    public function render_encryption_meta_box( $post ) {
        wp_nonce_field( 'ndk_encryption_meta_box', 'ndk_encryption_meta_box_nonce' );

        $encrypt_content = get_post_meta( $post->ID, '_ndk_encrypt_content', true );
        $is_encrypted = get_post_meta( $post->ID, '_ndk_is_encrypted', true );

        ?>
        <div class="ndk-meta-box">
            <?php if ( $is_encrypted ) : ?>
                <div class="notice notice-success inline">
                    <p><strong><?php _e( 'This content is quantum-encrypted!', 'neo-druidic-kyber' ); ?></strong></p>
                    <p><?php _e( 'Protected with ML-KEM-768 (Kyber) post-quantum cryptography.', 'neo-druidic-kyber' ); ?></p>
                </div>
            <?php endif; ?>

            <p>
                <label>
                    <input type="checkbox" name="ndk_encrypt_content" value="1" <?php checked( $encrypt_content, 1 ); ?>>
                    <?php _e( 'Encrypt this content', 'neo-druidic-kyber' ); ?>
                </label>
            </p>

            <p class="description">
                <?php _e( 'Enable quantum-safe encryption for this post. Content will be encrypted using ML-KEM-768 (Kyber).', 'neo-druidic-kyber' ); ?>
            </p>
        </div>
        <?php
    }

    /**
     * Save encryption meta
     */
    public function save_encryption_meta( $post_id ) {
        if ( ! isset( $_POST['ndk_encryption_meta_box_nonce'] ) ) {
            return;
        }

        if ( ! wp_verify_nonce( $_POST['ndk_encryption_meta_box_nonce'], 'ndk_encryption_meta_box' ) ) {
            return;
        }

        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $encrypt_content = isset( $_POST['ndk_encrypt_content'] ) ? 1 : 0;
        update_post_meta( $post_id, '_ndk_encrypt_content', $encrypt_content );
    }

    /**
     * Encrypted content shortcode
     */
    public function encrypted_shortcode( $atts, $content = '' ) {
        if ( ! is_user_logged_in() || empty( $content ) ) {
            return '<p class="ndk-encrypted-shortcode">' . __( '[Encrypted Content - Login Required]', 'neo-druidic-kyber' ) . '</p>';
        }

        $user_id = get_current_user_id();

        // Try to decrypt if already encrypted
        if ( strpos( $content, '[NDK_ENCRYPTED:' ) === 0 ) {
            // Extract encrypted data from shortcode
            preg_match( '/\[NDK_ENCRYPTED:(.*?)\]/', $content, $matches );

            if ( isset( $matches[1] ) ) {
                $encrypted_data = json_decode( base64_decode( $matches[1] ), true );
                $decrypted = NDK_Encryption::decrypt_content( $encrypted_data, $user_id );

                return $decrypted ? '<div class="ndk-decrypted-shortcode">' . do_shortcode( $decrypted ) . '</div>' : '[Unable to decrypt]';
            }
        }

        // Encrypt the content
        $encrypted = NDK_Encryption::encrypt_content( $content, $user_id );

        if ( ! $encrypted ) {
            return $content; // Fallback
        }

        $encoded = base64_encode( wp_json_encode( $encrypted ) );

        return '<div class="ndk-encrypted-shortcode">[NDK_ENCRYPTED:' . $encoded . ']</div>';
    }
}
